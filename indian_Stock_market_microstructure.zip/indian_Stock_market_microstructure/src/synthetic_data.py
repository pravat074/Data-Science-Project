"""
synthetic_data.py
------------------
Generates realistic, tick-by-tick trade-and-quote (TAQ) data for NSE-style
equities when a live/paid data feed is not available.

The simulator models three things every microstructure study needs:
  1. A latent "true" mid-price that follows a jump-diffusion process
     (captures both continuous price discovery and occasional informed
     trades / news shocks).
  2. A bid-ask spread that breathes with volatility and time-of-day
     (wide at the 09:15 open, narrow mid-session, widens again near the
     15:30 close - the classic U-shaped intraday liquidity pattern seen
     on the NSE).
  3. A Poisson trade-arrival process where trade direction (buy/sell) is
     correlated with recent order flow, so the data has realistic
     autocorrelation in trade signs (a key stylised fact in microstructure).

This is NOT meant to be a forecasting model. It exists so every metric in
metrics.py can be computed and sanity-checked end-to-end without a paid
data subscription. Swap generate_day() for a loader that reads real NSE
tick data (see README.md) and everything downstream keeps working.
"""

import numpy as np
import pandas as pd


NSE_OPEN = "09:15:00"
NSE_CLOSE = "15:30:00"


def _intraday_seconds_grid(date: str, freq_seconds: int = 1) -> pd.DatetimeIndex:
    start = pd.Timestamp(f"{date} {NSE_OPEN}")
    end = pd.Timestamp(f"{date} {NSE_CLOSE}")
    return pd.date_range(start, end, freq=f"{freq_seconds}s")


def _u_shape_multiplier(timestamps: pd.DatetimeIndex) -> np.ndarray:
    """Return a >=1 multiplier that is high near open/close, low midday."""
    total_secs = (timestamps - timestamps[0]).total_seconds()
    session_len = total_secs[-1]
    x = total_secs / session_len  # 0 .. 1
    # U-shape: 1 + amplitude * (distance from midpoint)^2, normalised
    return 1.0 + 1.8 * (2 * (x - 0.5)) ** 2


def generate_day(
    ticker: str,
    date: str,
    start_price: float,
    n_quote_updates: int = 6000,
    avg_trade_prob: float = 0.35,
    base_spread_bps: float = 4.0,
    daily_vol_bps: float = 120.0,
    jump_prob: float = 0.002,
    jump_size_bps: float = 40.0,
    seed: int | None = None,
) -> pd.DataFrame:
    """
    Simulate one trading day of quote-and-trade data for a single ticker.

    Returns a DataFrame with one row per quote-update tick:
        timestamp, ticker, bid, ask, bid_qty, ask_qty, mid,
        trade (bool), trade_price, trade_qty, trade_side (+1 buy / -1 sell)
    """
    rng = np.random.default_rng(seed)
    timestamps = _intraday_seconds_grid(date)
    # Subsample to n_quote_updates ticks across the session (tick-time, not
    # clock-time, which is realistic - activity clusters, it isn't uniform)
    if n_quote_updates < len(timestamps):
        idx = np.sort(rng.choice(len(timestamps), size=n_quote_updates, replace=False))
        timestamps = timestamps[idx]
    n = len(timestamps)

    u_shape = _u_shape_multiplier(timestamps)

    # --- latent mid price: GBM diffusion + occasional jumps ---
    per_tick_vol = (daily_vol_bps / 10000) / np.sqrt(n) * u_shape
    diffusion = rng.normal(0, per_tick_vol, size=n)
    jumps = np.where(
        rng.random(n) < jump_prob,
        rng.choice([-1, 1], size=n) * (jump_size_bps / 10000),
        0.0,
    )
    log_ret = diffusion + jumps
    mid = start_price * np.exp(np.cumsum(log_ret))

    # --- spread: base spread * U-shape * a bit of noise, floored at 1 tick ---
    tick_size = 0.05 if start_price < 250 else (0.10 if start_price < 1000 else 0.50)
    spread = (base_spread_bps / 10000) * mid * u_shape * (
        1 + 0.3 * np.abs(rng.normal(0, 1, size=n))
    )
    spread = np.maximum(spread, tick_size)
    # round spread to nearest tick
    spread = np.round(spread / tick_size) * tick_size
    spread = np.maximum(spread, tick_size)

    bid = np.round((mid - spread / 2) / tick_size) * tick_size
    ask = np.round((mid + spread / 2) / tick_size) * tick_size
    ask = np.maximum(ask, bid + tick_size)

    # --- depth: inversely related to spread (wide spread -> thin book) ---
    base_depth = rng.integers(50, 400, size=n)
    depth_scale = 1.0 / (1.0 + (spread / tick_size - 1) * 0.15)
    bid_qty = np.maximum(1, (base_depth * depth_scale * rng.uniform(0.7, 1.3, size=n))).astype(int)
    ask_qty = np.maximum(1, (base_depth * depth_scale * rng.uniform(0.7, 1.3, size=n))).astype(int)

    # --- trades: Poisson-ish occurrence, side correlated with recent flow ---
    trade_flag = rng.random(n) < avg_trade_prob
    trade_side = np.zeros(n, dtype=int)
    momentum = 0.0
    for i in range(n):
        if trade_flag[i]:
            # order flow has short-term autocorrelation (herding / order splitting)
            p_buy = 0.5 + 0.25 * np.tanh(momentum)
            side = 1 if rng.random() < p_buy else -1
            trade_side[i] = side
            momentum = 0.7 * momentum + 0.3 * side
        else:
            momentum *= 0.9

    trade_price = np.where(
        trade_flag,
        np.where(trade_side == 1, ask, bid),
        np.nan,
    )
    trade_qty = np.where(
        trade_flag,
        rng.integers(1, 50, size=n) * (1 if start_price > 500 else 5),
        0,
    )

    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "ticker": ticker,
            "bid": bid,
            "ask": ask,
            "bid_qty": bid_qty,
            "ask_qty": ask_qty,
            "mid": (bid + ask) / 2,
            "trade": trade_flag,
            "trade_price": trade_price,
            "trade_qty": trade_qty,
            "trade_side": np.where(trade_flag, trade_side, 0),
        }
    )
    return df


def generate_universe(
    tickers_and_prices: dict[str, float],
    date: str,
    seed: int = 42,
    **kwargs,
) -> pd.DataFrame:
    """Generate a day of data for several tickers and concatenate them."""
    frames = []
    for i, (ticker, price) in enumerate(tickers_and_prices.items()):
        frames.append(
            generate_day(ticker, date, start_price=price, seed=seed + i, **kwargs)
        )
    return pd.concat(frames, ignore_index=True)


if __name__ == "__main__":
    sample = generate_day("RELIANCE", "2026-09-25", start_price=2950.0, seed=1)
    print(sample.head(10))
    print(f"\n{len(sample)} ticks generated.")
