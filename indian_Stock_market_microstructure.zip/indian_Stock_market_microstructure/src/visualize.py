"""
visualize.py
------------
Matplotlib plotting helpers for the microstructure metrics. Kept
dependency-light (matplotlib only) so the project runs in any plain
Python/pandas environment.
"""

import matplotlib
matplotlib.use("Agg")  # headless-safe
import matplotlib.pyplot as plt
import numpy as np

from . import metrics


def plot_spread_and_price(df, ticker: str, out_path: str):
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 7), sharex=True,
                                    gridspec_kw={"height_ratios": [2, 1]})
    ax1.plot(df["timestamp"], df["mid"], color="#1f77b4", lw=0.9, label="Mid price")
    ax1.plot(df["timestamp"], metrics.microprice(df), color="#d62728", lw=0.7,
              alpha=0.8, label="Microprice")
    ax1.set_title(f"{ticker} — intraday mid-price vs microprice")
    ax1.set_ylabel("Price (₹)")
    ax1.legend(loc="upper right", fontsize=8)

    spread_bps = metrics.quoted_spread_bps(df)
    ax2.plot(df["timestamp"], spread_bps, color="#2ca02c", lw=0.8)
    ax2.set_ylabel("Quoted spread (bps)")
    ax2.set_xlabel("Time")
    ax2.set_title("Intraday quoted spread (U-shaped liquidity pattern)")

    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def plot_ofi_vs_price_change(df, ticker: str, out_path: str, bucket: str = "1min"):
    t = df.set_index("timestamp").sort_index()
    ofi = metrics.order_flow_imbalance(df)
    ofi.index = df["timestamp"].values
    ofi_bucket = ofi.resample(bucket).sum()
    mid_change = t["mid"].resample(bucket).last().diff()

    data = np.column_stack([ofi_bucket.values, mid_change.values])
    data = data[~np.isnan(data).any(axis=1)]

    fig, ax = plt.subplots(figsize=(7, 6))
    if len(data) > 2:
        ax.scatter(data[:, 0], data[:, 1], s=14, alpha=0.6, color="#9467bd")
        coef = np.polyfit(data[:, 0], data[:, 1], 1)
        xs = np.linspace(data[:, 0].min(), data[:, 0].max(), 50)
        ax.plot(xs, np.polyval(coef, xs), color="black", lw=1.2,
                label=f"slope={coef[0]:.5f}")
        ax.legend(fontsize=8)
    ax.axhline(0, color="grey", lw=0.5)
    ax.axvline(0, color="grey", lw=0.5)
    ax.set_xlabel(f"Order flow imbalance ({bucket} bucket)")
    ax.set_ylabel("Mid-price change (₹)")
    ax.set_title(f"{ticker} — OFI vs subsequent price change")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def plot_volatility_signature(df, ticker: str, out_path: str,
                               buckets=("10s", "30s", "1min", "2min", "5min", "10min")):
    trades = df[df["trade"]].copy().reset_index(drop=True)
    vols = []
    for b in buckets:
        rv = metrics.realized_volatility(trades, bucket=b)
        vols.append(rv.mean())

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(range(len(buckets)), vols, marker="o", color="#ff7f0e")
    ax.set_xticks(range(len(buckets)))
    ax.set_xticklabels(buckets)
    ax.set_xlabel("Sampling frequency")
    ax.set_ylabel("Annualised realized volatility")
    ax.set_title(f"{ticker} — volatility signature plot\n"
                  f"(flattening at coarser frequencies = less microstructure noise)")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def plot_cross_sectional_comparison(summary_df, out_path: str):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    metrics_to_plot = [
        ("avg_quoted_spread_bps", "Avg quoted spread (bps)"),
        ("kyle_lambda", "Kyle's λ (price impact)"),
        ("amihud_illiquidity_mean", "Amihud illiquidity"),
    ]
    for ax, (col, title) in zip(axes, metrics_to_plot):
        ax.bar(summary_df["ticker"], summary_df[col], color="#17becf")
        ax.set_title(title, fontsize=10)
        ax.tick_params(axis="x", rotation=30)
    fig.suptitle("Cross-sectional microstructure comparison")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
