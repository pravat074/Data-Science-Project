"""
metrics.py
----------
A library of standard market-microstructure metrics, computed from
tick-level quote-and-trade (TAQ) data. Every function takes a per-ticker
DataFrame with (at least) these columns, as produced by synthetic_data.py
or a real NSE/BSE tick feed once mapped to this schema:

    timestamp, bid, ask, mid, trade, trade_price, trade_qty, trade_side

No statsmodels dependency - all regressions use numpy.linalg.lstsq so the
module runs anywhere pandas/numpy are available.
"""

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------
# 1. Spread measures
# --------------------------------------------------------------------------

def quoted_spread(df: pd.DataFrame) -> pd.Series:
    """Absolute quoted (bid-ask) spread at each tick."""
    return df["ask"] - df["bid"]


def quoted_spread_bps(df: pd.DataFrame) -> pd.Series:
    """Quoted spread in basis points of the mid-price."""
    return (df["ask"] - df["bid"]) / df["mid"] * 10000


def effective_spread_bps(trades: pd.DataFrame) -> pd.Series:
    """
    Effective spread = 2 * |trade_price - mid_at_trade| / mid_at_trade.
    Measures the cost actually paid relative to the prevailing mid,
    which can differ from the quoted spread if the trade moves the book.
    """
    return 2 * (trades["trade_price"] - trades["mid"]).abs() / trades["mid"] * 10000


def realized_spread_bps(trades: pd.DataFrame, horizon: int = 30) -> pd.Series:
    """
    Realized spread = 2 * trade_side * (trade_price - mid_{t+horizon}) / mid.
    Nets out the *permanent* price-impact component from the effective
    spread, leaving the market maker's realised revenue. horizon is in
    number of subsequent ticks (a proxy for a fixed post-trade window).
    """
    future_mid = trades["mid"].shift(-horizon)
    rs = 2 * trades["trade_side"] * (trades["trade_price"] - future_mid) / trades["mid"]
    return rs * 10000


# --------------------------------------------------------------------------
# 2. Price impact / information content of trades
# --------------------------------------------------------------------------

def price_impact_bps(trades: pd.DataFrame, horizon: int = 30) -> pd.Series:
    """
    Price impact = 2 * trade_side * (mid_{t+horizon} - mid_t) / mid_t.
    The complement of realized spread: how much of the trade's cost was
    "informed" (permanently moved the price) rather than compensation to
    the liquidity provider.
    """
    future_mid = trades["mid"].shift(-horizon)
    pi = 2 * trades["trade_side"] * (future_mid - trades["mid"]) / trades["mid"]
    return pi * 10000


def kyle_lambda(trades: pd.DataFrame, bucket: str = "1min") -> dict:
    """
    Kyle's (1985) lambda: price impact per unit of signed order flow.
    Estimated by OLS of mid-price change on net signed volume, aggregated
    into time buckets (using raw tick data is too noisy).

        delta_mid_bucket = lambda * signed_volume_bucket + eps

    Returns {'lambda': float, 'r_squared': float, 'n_buckets': int}.
    A higher lambda means the market is less liquid / more prone to
    price impact from a given order size - useful for comparing large-cap
    vs mid-cap NSE names.
    """
    t = trades.set_index("timestamp").sort_index()
    signed_vol = (t["trade_side"] * t["trade_qty"]).resample(bucket).sum()
    mid_bucket = t["mid"].resample(bucket).last().ffill()
    delta_mid = mid_bucket.diff()

    data = pd.concat([signed_vol, delta_mid], axis=1).dropna()
    data.columns = ["signed_vol", "delta_mid"]
    if len(data) < 5 or data["signed_vol"].std() == 0:
        return {"lambda": np.nan, "r_squared": np.nan, "n_buckets": len(data)}

    x = np.vstack([data["signed_vol"].values, np.ones(len(data))]).T
    y = data["delta_mid"].values
    coef, *_ = np.linalg.lstsq(x, y, rcond=None)
    lam, intercept = coef
    y_hat = x @ coef
    ss_res = np.sum((y - y_hat) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan
    return {"lambda": lam, "r_squared": r2, "n_buckets": len(data)}


def amihud_illiquidity(trades: pd.DataFrame, bucket: str = "5min") -> pd.Series:
    """
    Amihud (2002) illiquidity ratio: |return| / rupee volume, per bucket.
    Widely used because it needs only trade price and volume (no order
    book), so it works even on lower-frequency NSE bhavcopy-style data.
    """
    t = trades.set_index("timestamp").sort_index()
    price = t["trade_price"].resample(bucket).last().ffill()
    ret = price.pct_change().abs()
    rupee_vol = (t["trade_price"] * t["trade_qty"]).resample(bucket).sum()
    illiq = (ret / rupee_vol).replace([np.inf, -np.inf], np.nan)
    return illiq * 1e6  # scaled for readability


# --------------------------------------------------------------------------
# 3. Order flow & trade classification
# --------------------------------------------------------------------------

def order_flow_imbalance(df: pd.DataFrame) -> pd.Series:
    """
    Depth-based order flow imbalance (OFI), Cont-Kukanov-Stoikov style,
    approximated from best bid/ask size changes:
        OFI = delta(bid_qty) - delta(ask_qty)   (same-side additions minus
                                                   opposite-side depletions)
    Positive OFI => buy-side pressure building.
    """
    d_bid = df["bid_qty"].diff().fillna(0)
    d_ask = df["ask_qty"].diff().fillna(0)
    # only count same-price-level changes as genuine OFI contributions
    same_bid = (df["bid"].diff() == 0).astype(int)
    same_ask = (df["ask"].diff() == 0).astype(int)
    return d_bid * same_bid - d_ask * same_ask


def lee_ready_classification(df: pd.DataFrame) -> pd.Series:
    """
    Lee-Ready (1991) trade-direction algorithm, for feeds that only give
    a trade price (no exchange-supplied aggressor flag): classify each
    trade as buy (+1) if price is above the prevailing mid (quote rule),
    else sell (-1); ties are broken with the tick rule (compare to the
    previous trade price).
    """
    mid = df["mid"]
    price = df["trade_price"]
    side = np.sign(price - mid)
    # tick rule for ties
    tick = np.sign(price.diff())
    tick = tick.replace(0, np.nan).ffill().fillna(0)
    side = np.where(side == 0, tick, side)
    return pd.Series(side, index=df.index, name="lee_ready_side")


def classification_accuracy(df: pd.DataFrame) -> float:
    """Compare Lee-Ready inferred side against the true simulated side
    (only meaningful on synthetic data, where ground truth exists)."""
    trades = df[df["trade"]].copy()
    inferred = lee_ready_classification(trades)
    match = (inferred.values == trades["trade_side"].values).mean()
    return match


# --------------------------------------------------------------------------
# 4. Volatility & the Roll (1984) implied-spread estimator
# --------------------------------------------------------------------------

def roll_implied_spread_bps(trades: pd.DataFrame, bucket: str = "5min") -> pd.Series:
    """
    Roll's (1984) implied spread from the serial covariance of price
    changes: spread = 2 * sqrt(-cov(delta_p_t, delta_p_{t-1})) when that
    covariance is negative (as bid-ask bounce implies). Needs only trade
    prices, so it's a useful cross-check against the directly quoted
    spread.
    """
    t = trades.set_index("timestamp").sort_index()
    price = t["trade_price"].resample(bucket).last().ffill()
    dp = price.diff().dropna()

    out = {}
    buckets = dp.index.floor("30min").unique()  # coarser window per Roll estimate
    for b in buckets:
        window = dp[(dp.index >= b) & (dp.index < b + pd.Timedelta("30min"))]
        if len(window) < 5:
            continue
        cov = np.cov(window.values[:-1], window.values[1:])[0, 1]
        spread = 2 * np.sqrt(-cov) if cov < 0 else np.nan
        mid_ref = price[(price.index >= b) & (price.index < b + pd.Timedelta("30min"))].mean()
        out[b] = spread / mid_ref * 10000 if mid_ref else np.nan
    return pd.Series(out, name="roll_spread_bps")


def realized_volatility(trades: pd.DataFrame, bucket: str = "5min") -> pd.Series:
    """Realized volatility (sum of squared returns) per bucket, annualised
    assuming a ~6h15m NSE session and 252 trading days."""
    t = trades.set_index("timestamp").sort_index()
    price = t["trade_price"].resample("1s").last().ffill()
    ret = price.pct_change().fillna(0)
    rv = ret.pow(2).resample(bucket).sum().pow(0.5)
    seconds_per_bucket = pd.Timedelta(bucket).total_seconds()
    session_seconds = 6.25 * 3600
    buckets_per_day = session_seconds / seconds_per_bucket
    annualised = rv * np.sqrt(buckets_per_day * 252)
    return annualised


# --------------------------------------------------------------------------
# 5. Microprice
# --------------------------------------------------------------------------

def microprice(df: pd.DataFrame) -> pd.Series:
    """
    Stoikov's microprice: a depth-weighted mid-price that leans toward
    the side with less resting size (i.e., the side more likely to be
    consumed next), a better short-horizon fair-value estimate than the
    simple mid.
        microprice = bid * (ask_qty / (bid_qty+ask_qty)) + ask * (bid_qty / (bid_qty+ask_qty))
    """
    total_qty = df["bid_qty"] + df["ask_qty"]
    return (df["bid"] * df["ask_qty"] + df["ask"] * df["bid_qty"]) / total_qty


# --------------------------------------------------------------------------
# 6. Summary table for a single ticker/day
# --------------------------------------------------------------------------

def summarize_ticker(df: pd.DataFrame) -> dict:
    trades = df[df["trade"]].copy().reset_index(drop=True)
    kyle = kyle_lambda(trades)
    return {
        "ticker": df["ticker"].iloc[0],
        "n_ticks": len(df),
        "n_trades": len(trades),
        "avg_quoted_spread_bps": quoted_spread_bps(df).mean(),
        "avg_effective_spread_bps": effective_spread_bps(trades).mean(),
        "avg_realized_spread_bps": realized_spread_bps(trades).mean(),
        "avg_price_impact_bps": price_impact_bps(trades).mean(),
        "kyle_lambda": kyle["lambda"],
        "kyle_r_squared": kyle["r_squared"],
        "amihud_illiquidity_mean": amihud_illiquidity(trades).mean(),
        "lee_ready_accuracy": classification_accuracy(df),
        "avg_roll_spread_bps": roll_implied_spread_bps(trades).mean(),
        "avg_realized_vol_annualised": realized_volatility(trades).mean(),
    }
