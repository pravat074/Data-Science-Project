# Indian Stock Market Microstructure Analysis

A self-contained Python project that computes standard market-microstructure
metrics — spreads, price impact, order flow imbalance, illiquidity, realized
volatility — for NSE-listed equities.

Since no live/paid tick-data subscription is connected, the project ships
with a **realistic synthetic data generator** (`src/synthetic_data.py`) so
every metric can be computed and sanity-checked end-to-end today. Swap in a
real feed (see [Using real data](#using-real-data-instead-of-synthetic)
below) and the rest of the pipeline — metrics, plots, summary table — works
unchanged, since it only depends on a standard tick-data schema.

## Project structure

```
indian_market_microstructure/
├── main.py                  # orchestrates the whole run
├── requirements.txt
├── src/
│   ├── synthetic_data.py    # NSE-style tick data simulator
│   ├── metrics.py           # spread, impact, OFI, illiquidity, volatility
│   └── visualize.py         # matplotlib plots
└── outputs/                 # generated CSVs + PNGs (created on run)
```

## Quick start

```bash
pip install -r requirements.txt
python main.py
```

This simulates one trading day (09:15–15:30 IST) for a 4-stock basket
(RELIANCE, TCS, HDFCBANK, IEX — chosen to span large-cap/liquid to
mid-cap/less-liquid), computes every metric below for each stock, and
writes to `outputs/`:

- `<TICKER>_ticks.csv` — raw simulated tick data
- `<TICKER>_spread_price.png` — mid-price/microprice + intraday spread
- `<TICKER>_ofi.png` — order flow imbalance vs. subsequent price change
- `<TICKER>_vol_signature.png` — volatility signature plot
- `cross_sectional_comparison.png` — spread/impact/illiquidity across the basket
- `summary.csv` — one row per ticker with every metric

## Metrics implemented (`src/metrics.py`)

| Category | Metric | What it captures |
|---|---|---|
| Spread | Quoted spread (bps) | Cost quoted by the book right now |
| Spread | Effective spread | Cost actually paid vs. mid at trade time |
| Spread | Realized spread | Market maker's net revenue after price moves |
| Impact | Price impact | Permanent, information-driven price move from a trade |
| Impact | Kyle's λ (1985) | Price impact per unit of signed order flow (OLS) |
| Impact | Amihud (2002) illiquidity | \|return\| per rupee of volume |
| Impact | Roll's (1984) implied spread | Spread inferred from price-change serial covariance |
| Flow | Order flow imbalance (OFI) | Buy vs. sell pressure building in the book |
| Flow | Lee-Ready (1991) classification | Infers trade aggressor side from price vs. quote |
| Price | Microprice (Stoikov) | Depth-weighted fair value, better short-horizon estimate than mid |
| Volatility | Realized volatility | Sum of squared returns, annualised, at multiple sampling frequencies |

Each function is documented in `src/metrics.py` with the formula and why
it matters. `metrics.summarize_ticker()` bundles them all into one dict
per stock, which `main.py` turns into `summary.csv`.

## Using real data instead of synthetic

Replace the call to `src.synthetic_data.generate_day()` in `main.py` with
a loader that returns a DataFrame in the same schema:

```
timestamp, ticker, bid, ask, bid_qty, ask_qty, mid,
trade, trade_price, trade_qty, trade_side
```

Realistic sources for NSE/BSE data, roughly cheapest → most complete:

- **NSE bhavcopy / market-data downloads** (free, EOD/daily — good for
  Amihud illiquidity and Roll's spread, not tick-level metrics)
- **Broker APIs** — Zerodha Kite Connect, Upstox, Angel One SmartAPI
  (paid tiers give tick-level LTP + best-bid/ask via websocket)
- **Vendor tick/order-book feeds** — TrueData, GDFL (Global Data Feed &
  Analytics Ltd — the standard source for NSE tick-by-tick + full order
  book replay data used in most Indian academic microstructure papers),
  Refinitiv/LSEG Tick History
- `trade_side` (needed for OFI, Kyle's λ, realized spread) usually isn't
  supplied directly — if your feed lacks an aggressor flag, use
  `metrics.lee_ready_classification()` already included here to infer it.

## Known simplifications

- Single price level (best bid/ask only) — no full order-book depth (L2/L3).
  Extending to depth-weighted OFI across levels 1–5 is a natural next step.
- Synthetic trade/quote arrival is Poisson-ish, not calibrated to any
  specific stock's real intraday activity profile.
- Kyle's λ and Roll's spread are estimated per bucket with OLS/serial
  covariance — fine for illustration, but a production study would want
  Newey-West standard errors and multiple-day pooling.
- No corporate actions, circuit limits, or auction-session (pre-open)
  modeling — session is treated as continuous 09:15–15:30 only.

## Extending this project

Natural next additions, roughly in order of effort:
1. Multi-day runs + time-series plots of daily-average spread/λ (regime detection)
2. Full L2 order-book depth and depth-weighted OFI (Cont-Kukanov-Stoikov)
3. VPIN (volume-synchronized probability of informed trading) for toxicity flagging
4. Event study around results announcements / index rebalancing days
5. A Jupyter notebook wrapping `main.py` for interactive exploration
