"""
main.py
-------
End-to-end run: generate a day of synthetic NSE tick data for a small
basket of stocks, compute the full microstructure metric set for each,
save CSV outputs and plots, and print a cross-sectional summary table.

Usage:
    python main.py
"""

import os
import pandas as pd

from src.synthetic_data import generate_day
from src import metrics, visualize

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")

# A small basket spanning large-cap (liquid) to mid-cap (less liquid) NSE
# names, with approximate representative prices. Swap this dict - or the
# whole data source - for a real feed; see README.md.
UNIVERSE = {
    "RELIANCE": 2950.0,   # large-cap, tight spreads expected
    "TCS": 4100.0,        # large-cap IT
    "HDFCBANK": 1680.0,   # large-cap banking
    "IEX": 165.0,         # mid-cap, wider spreads / more impact expected
}

TRADING_DATE = "2026-09-25"


def run():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    summaries = []

    for i, (ticker, price) in enumerate(UNIVERSE.items()):
        print(f"Simulating {ticker} ...")
        # mid/large caps get tighter base spread & more quote updates;
        # smaller names get wider spreads & thinner activity
        is_liquid = price > 500
        df = generate_day(
            ticker,
            TRADING_DATE,
            start_price=price,
            n_quote_updates=6000 if is_liquid else 3000,
            base_spread_bps=3.0 if is_liquid else 12.0,
            daily_vol_bps=100 if is_liquid else 180,
            seed=100 + i,
        )
        df.to_csv(os.path.join(OUTPUT_DIR, f"{ticker}_ticks.csv"), index=False)

        summary = metrics.summarize_ticker(df)
        summaries.append(summary)

        visualize.plot_spread_and_price(
            df, ticker, os.path.join(OUTPUT_DIR, f"{ticker}_spread_price.png")
        )
        visualize.plot_ofi_vs_price_change(
            df, ticker, os.path.join(OUTPUT_DIR, f"{ticker}_ofi.png")
        )
        visualize.plot_volatility_signature(
            df, ticker, os.path.join(OUTPUT_DIR, f"{ticker}_vol_signature.png")
        )

    summary_df = pd.DataFrame(summaries)
    summary_df.to_csv(os.path.join(OUTPUT_DIR, "summary.csv"), index=False)
    visualize.plot_cross_sectional_comparison(
        summary_df, os.path.join(OUTPUT_DIR, "cross_sectional_comparison.png")
    )

    pd.set_option("display.float_format", lambda x: f"{x:,.4f}")
    print("\n=== Cross-sectional microstructure summary ===")
    print(summary_df.to_string(index=False))
    print(f"\nAll CSVs and plots written to: {OUTPUT_DIR}")


if __name__ == "__main__":
    run()
