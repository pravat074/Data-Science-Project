# Movie Recommendation System

A self-contained Python project implementing and benchmarking five classic
recommendation algorithms — a non-personalized popularity baseline,
user-based and item-based collaborative filtering, SGD-trained matrix
factorization, and content-based (genre TF-IDF) filtering — evaluated on
the same rating-prediction and top-K ranking metrics.

No live catalog or ratings API (TMDB, a MovieLens-style database, a
production ratings store) was connected when this was built, so the
project ships with a **realistic synthetic user/movie/rating generator**
(`src/synthetic_data.py`) that reproduces the key stylised facts of real
recommender data: latent taste structure, popularity long-tails, and
missing-not-at-random sparsity. Swap in a real dataset (see
[Using real data](#using-real-data-instead-of-synthetic) below) and every
model and metric keeps working unchanged, since they only depend on a
plain `(user_id, movie_id, rating)` schema.

## Project structure

```
movie_recommendation_system/
├── main.py                  # orchestrates the whole run
├── requirements.txt
├── src/
│   ├── synthetic_data.py    # synthetic catalog + rating-history generator
│   ├── recommenders.py      # 5 recommendation algorithms
│   ├── evaluation.py        # RMSE/MAE, Precision@K, Recall@K, Coverage@K
│   └── visualize.py         # matplotlib plots
└── outputs/                 # generated CSVs + PNG charts
```

## Quick start

```bash
pip install -r requirements.txt
python main.py
```

This generates a synthetic catalog of 200 movies and 500 users
(~13% rating density, ~12,800 ratings), fits all five models on an 80/20
per-user train/test split, evaluates each, and writes to `outputs/`:

- `movies.csv`, `ratings.csv` — the generated catalog and rating history
- `model_comparison.csv` / `.png` — RMSE, MAE, Precision@10, Recall@10, Coverage@10 for every model
- `rating_distribution.png` — overall rating histogram + the ratings-per-movie long tail
- `genre_popularity.png` — rating volume and average score by genre
- `mf_training_curve.png` — SGD training-RMSE curve for matrix factorization
- `latent_space.png` — PCA projection of the learned movie vectors, colored by genre (genre is never given to the model — this checks whether it re-discovers genre structure on its own)

Running it also prints a top-10 recommendation list for a demo user from
every model, so you can see how differently each algorithm ranks the same
catalog.

## Algorithms implemented (`src/recommenders.py`)

| Model | Idea | Strength | Weakness |
|---|---|---|---|
| **Popularity** | Bayesian-shrunk average rating, same list for everyone | Simple, always-available baseline | Zero personalization |
| **User-Based CF** | Weighted average of similar *users'* ratings | Captures "people like you" signal | Struggles as users >> compute; cold-start for new users |
| **Item-Based CF** | Weighted average of similar *items'* ratings from the same user | More stable than user-based at scale | Still needs the target user's own history |
| **Matrix Factorization** | Learns latent taste vectors `p_u`, `q_i` by SGD on observed ratings only (Funk-SVD style) | Best accuracy here; the approach behind most of the Netflix Prize winners | Cold-start for brand-new users/items; less interpretable |
| **Content-Based** | TF-IDF over genre tags; user profile = liked movies' average vector | Works with zero other users' data (solves cold-start) | Can't capture taste that isn't in the genre metadata |

## Evaluation (`src/evaluation.py`)

Two families of metrics, because they measure different things:

- **Rating-prediction accuracy** — RMSE, MAE. "If I ask this model what
  you'd rate a specific movie, how close is it?"
- **Top-K ranking quality** — Precision@K, Recall@K, Hit Rate, and catalog
  **Coverage@K** (what fraction of the whole catalog ever appears in
  *anyone's* top-K list — a low-coverage model just recommends the same
  handful of blockbusters to everyone).

`evaluate_all()` runs every model through both families and returns one
tidy comparison row per model — this is exactly what `model_comparison.csv`
contains.

## A genuine accuracy/diversity trade-off

In the default run, Matrix Factorization wins on RMSE/MAE and Recall@K —
but has noticeably *lower* Coverage@K than the collaborative-filtering
models. This isn't a bug: it's the well-documented accuracy-vs-diversity
trade-off in recommender systems. A model optimized purely for prediction
accuracy tends to concentrate on items it's most confident about (usually
the popular ones), while neighborhood methods naturally surface a wider
slice of the catalog. Production systems typically re-rank with an
explicit diversity or novelty term to correct for this.

## Using real data instead of synthetic

Replace the call to `src.synthetic_data.generate_dataset()` in `main.py`
with a loader that returns:

- a `movies` DataFrame with at least `movie_id, title, genres`
- a `ratings` DataFrame with `user_id, movie_id, rating, timestamp`

Realistic sources, roughly easiest → most complete:

- **MovieLens** (25M / 1M / 100K) — the standard academic benchmark dataset, free for research use
- **TMDB API** — for a live, growing catalog with genres, cast, overview text (which would let `ContentBasedRecommender` use far richer text than just genre tags)
- **Your own product's ratings/implicit-feedback logs** — clicks, watches, and add-to-list events can substitute for explicit ratings via `evaluation.precision_recall_at_k`'s relevance-threshold logic

`ContentBasedRecommender.fit()` already accepts any `movies_df` with a
`genres` column — feeding it real TMDB genre/keyword data requires no
code changes at all.

## Known simplifications

- Content-based filtering only uses genre tags, not plot text, cast, or crew — a real deployment would TF-IDF (or embed) a synopsis for much richer content signal.
- Matrix factorization uses fixed hyperparameters (20 factors, 30 epochs, no learning-rate schedule) — a production system would tune these via a validation split.
- No temporal modeling — ratings are treated as i.i.d., ignoring the fact that tastes and catalogs both drift over time.
- No implicit-feedback signal (watches, clicks, watch-time) — only explicit 1-5 star ratings are modeled.
- Neighborhood CF computes a full user-user or item-item similarity matrix in memory, which doesn't scale past tens of thousands of users/items without approximate nearest-neighbor techniques.

## Extending this project

Natural next additions, roughly in order of effort:
1. Hybrid re-ranking that blends Matrix Factorization's accuracy with a diversity/novelty term to close the Coverage@K gap
2. Hyperparameter search (factors, regularization, learning rate) via a validation split
3. Implicit-feedback models (e.g. Bayesian Personalized Ranking) for click/watch data instead of star ratings
4. A simple Flask/FastAPI endpoint wrapping `MatrixFactorizationRecommender.recommend()` for live serving
5. Cold-start blending: fall back to Content-Based or Popularity for users/items with too little history for CF/MF
