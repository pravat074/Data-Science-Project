"""
recommenders.py
----------------
Five recommendation algorithms, from a non-personalized baseline to
model-based collaborative filtering, all implemented against the same
simple interface:

    model.fit(train_ratings_df)
    model.predict(user_id, movie_id) -> float           # rating prediction
    model.recommend(user_id, k, exclude) -> [movie_id, ...]  # top-K ranking

Not every model supports both operations equally well (pure ranking models
like popularity don't really "predict a rating" in a meaningful sense), but
implementing both lets evaluation.py score every model on the same metrics.
"""

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer


class BaseRecommender:
    name = "base"

    def fit(self, train: pd.DataFrame):
        raise NotImplementedError

    def predict(self, user_id: int, movie_id: int) -> float:
        raise NotImplementedError

    def recommend(self, user_id: int, k: int, exclude: set) -> list:
        raise NotImplementedError


# --------------------------------------------------------------------------
# 1. Popularity baseline (non-personalized)
# --------------------------------------------------------------------------

class PopularityRecommender(BaseRecommender):
    """
    Ranks movies by a Bayesian-averaged rating (shrinks a movie's average
    toward the global mean when it has few ratings), so a single 5-star
    rating can't outrank a movie with thousands of consistently good ones.
    This is the standard "what would Netflix show a brand-new user"
    baseline that every personalized model should beat.
    """
    name = "Popularity"

    def __init__(self, min_votes: int = 5):
        self.min_votes = min_votes

    def fit(self, train: pd.DataFrame):
        self.global_mean = train["rating"].mean()
        stats = train.groupby("movie_id")["rating"].agg(["mean", "count"])
        m = self.min_votes
        stats["score"] = (stats["count"] / (stats["count"] + m)) * stats["mean"] + \
                          (m / (stats["count"] + m)) * self.global_mean
        self.scores = stats["score"].sort_values(ascending=False)
        return self

    def predict(self, user_id, movie_id):
        return self.scores.get(movie_id, self.global_mean)

    def recommend(self, user_id, k, exclude):
        ranked = [m for m in self.scores.index if m not in exclude]
        return ranked[:k]


# --------------------------------------------------------------------------
# 2 & 3. Neighborhood-based collaborative filtering (user-based / item-based)
# --------------------------------------------------------------------------

class NeighborhoodCF(BaseRecommender):
    """
    Classic memory-based collaborative filtering. mode='user' finds users
    with similar rating patterns and predicts a target rating as a
    similarity-weighted average of what similar users gave that movie;
    mode='item' does the mirror-image using item-item similarity (this is
    the algorithm family that powered the original Amazon "customers who
    bought this also bought" recommendations).
    """

    def __init__(self, mode: str = "user", k_neighbors: int = 30):
        assert mode in ("user", "item")
        self.mode = mode
        self.k_neighbors = k_neighbors
        self.name = "User-Based CF" if mode == "user" else "Item-Based CF"

    def fit(self, train: pd.DataFrame):
        self.global_mean = train["rating"].mean()
        self.user_ids = np.sort(train["user_id"].unique())
        self.movie_ids = np.sort(train["movie_id"].unique())
        self.u_index = {u: i for i, u in enumerate(self.user_ids)}
        self.m_index = {m: i for i, m in enumerate(self.movie_ids)}

        mat = np.zeros((len(self.user_ids), len(self.movie_ids)))
        mask = np.zeros_like(mat, dtype=bool)
        for row in train.itertuples():
            ui, mi = self.u_index[row.user_id], self.m_index[row.movie_id]
            mat[ui, mi] = row.rating
            mask[ui, mi] = True

        self.user_mean = np.array([mat[i, mask[i]].mean() if mask[i].any() else self.global_mean
                                    for i in range(len(self.user_ids))])
        centered = np.where(mask, mat - self.user_mean[:, None], 0.0)

        self.mat, self.mask, self.centered = mat, mask, centered
        if self.mode == "user":
            self.sim = cosine_similarity(centered)
            np.fill_diagonal(self.sim, 0)
        else:
            self.sim = cosine_similarity(centered.T)
            np.fill_diagonal(self.sim, 0)
        return self

    def _predict_idx(self, ui, mi):
        if self.mode == "user":
            col_mask = self.mask[:, mi]
            if not col_mask.any():
                return self.user_mean[ui]
            sims = self.sim[ui, col_mask]
            vals = self.centered[col_mask, mi]
        else:
            row_mask = self.mask[ui, :]
            if not row_mask.any():
                return self.user_mean[ui]
            sims = self.sim[mi, row_mask]
            vals = self.centered[ui, row_mask]

        if len(sims) == 0:
            return self.user_mean[ui]
        top = np.argsort(-np.abs(sims))[: self.k_neighbors]
        sims_top, vals_top = sims[top], vals[top]
        denom = np.abs(sims_top).sum()
        if denom < 1e-8:
            return self.user_mean[ui]
        pred = self.user_mean[ui] + (sims_top @ vals_top) / denom
        return float(np.clip(pred, 1.0, 5.0))

    def predict(self, user_id, movie_id):
        if user_id not in self.u_index or movie_id not in self.m_index:
            return self.global_mean
        return self._predict_idx(self.u_index[user_id], self.m_index[movie_id])

    def recommend(self, user_id, k, exclude):
        if user_id not in self.u_index:
            return []
        ui = self.u_index[user_id]
        candidates = [m for m in self.movie_ids if m not in exclude]
        scored = [(m, self._predict_idx(ui, self.m_index[m])) for m in candidates]
        scored.sort(key=lambda x: -x[1])
        return [m for m, _ in scored[:k]]


# --------------------------------------------------------------------------
# 4. Matrix factorization (Funk-SVD style, trained by SGD)
# --------------------------------------------------------------------------

class MatrixFactorizationRecommender(BaseRecommender):
    """
    Learns a low-rank latent-factor model
        rating(u, i) ~= mu + b_u + b_i + p_u . q_i
    by stochastic gradient descent directly on the *observed* ratings only
    (unlike a plain SVD, it never has to invent zeros for missing entries,
    which is what makes Funk-SVD-style training the standard approach for
    sparse rating matrices - this is essentially the algorithm that won
    the bulk of the Netflix Prize).
    """
    name = "Matrix Factorization"

    def __init__(self, n_factors=20, n_epochs=30, lr=0.01, reg=0.03, seed=0):
        self.n_factors, self.n_epochs, self.lr, self.reg = n_factors, n_epochs, lr, reg
        self.seed = seed

    def fit(self, train: pd.DataFrame):
        rng = np.random.default_rng(self.seed)
        self.global_mean = train["rating"].mean()
        self.user_ids = np.sort(train["user_id"].unique())
        self.movie_ids = np.sort(train["movie_id"].unique())
        self.u_index = {u: i for i, u in enumerate(self.user_ids)}
        self.m_index = {m: i for i, m in enumerate(self.movie_ids)}

        n_u, n_m, f = len(self.user_ids), len(self.movie_ids), self.n_factors
        self.P = rng.normal(0, 0.1, size=(n_u, f))
        self.Q = rng.normal(0, 0.1, size=(n_m, f))
        self.b_u = np.zeros(n_u)
        self.b_i = np.zeros(n_m)

        ui = train["user_id"].map(self.u_index).values
        mi = train["movie_id"].map(self.m_index).values
        r = train["rating"].values
        n = len(r)

        history = []
        for epoch in range(self.n_epochs):
            order = rng.permutation(n)
            sq_err = 0.0
            for idx in order:
                u, m, rating = ui[idx], mi[idx], r[idx]
                pred = self.global_mean + self.b_u[u] + self.b_i[m] + self.P[u] @ self.Q[m]
                err = rating - pred
                sq_err += err ** 2
                self.b_u[u] += self.lr * (err - self.reg * self.b_u[u])
                self.b_i[m] += self.lr * (err - self.reg * self.b_i[m])
                p_u = self.P[u].copy()
                self.P[u] += self.lr * (err * self.Q[m] - self.reg * self.P[u])
                self.Q[m] += self.lr * (err * p_u - self.reg * self.Q[m])
            history.append(np.sqrt(sq_err / n))
        self.train_rmse_history = history
        return self

    def predict(self, user_id, movie_id):
        if user_id not in self.u_index or movie_id not in self.m_index:
            return self.global_mean
        u, m = self.u_index[user_id], self.m_index[movie_id]
        pred = self.global_mean + self.b_u[u] + self.b_i[m] + self.P[u] @ self.Q[m]
        return float(np.clip(pred, 1.0, 5.0))

    def recommend(self, user_id, k, exclude):
        if user_id not in self.u_index:
            return []
        u = self.u_index[user_id]
        scores = self.global_mean + self.b_u[u] + self.b_i + self.Q @ self.P[u]
        order = np.argsort(-scores)
        out = []
        for idx in order:
            m = self.movie_ids[idx]
            if m not in exclude:
                out.append(m)
                if len(out) == k:
                    break
        return out


# --------------------------------------------------------------------------
# 5. Content-based filtering (genre TF-IDF)
# --------------------------------------------------------------------------

class ContentBasedRecommender(BaseRecommender):
    """
    Builds a TF-IDF vector per movie from its genre tags, represents each
    user as the (rating-weighted) average of the vectors of movies they
    liked, and scores unseen movies by cosine similarity to that profile.
    Needs no other users' data at all, so it's the standard answer to the
    cold-start problem for a brand-new catalog title.
    """
    name = "Content-Based"

    def fit(self, train: pd.DataFrame, movies_df: pd.DataFrame = None):
        assert movies_df is not None, "ContentBasedRecommender needs movies_df"
        self.movies_df = movies_df.set_index("movie_id")
        self.global_mean = train["rating"].mean()
        corpus = self.movies_df["genres"].str.replace("|", " ", regex=False)
        self.vectorizer = TfidfVectorizer()
        self.item_vectors = self.vectorizer.fit_transform(corpus)
        self.movie_ids = self.movies_df.index.values
        self.m_index = {m: i for i, m in enumerate(self.movie_ids)}

        self.user_profiles = {}
        for uid, grp in train.groupby("user_id"):
            idxs = [self.m_index[m] for m in grp["movie_id"] if m in self.m_index]
            if not idxs:
                continue
            weights = (grp["rating"].values - self.global_mean)
            weights = np.clip(weights, 0.01, None)  # only "liked" movies build the profile
            vecs = self.item_vectors[idxs]
            profile = np.asarray(vecs.multiply(weights[:, None]).mean(axis=0))
            self.user_profiles[uid] = profile
        return self

    def _score_all(self, user_id):
        profile = self.user_profiles.get(user_id)
        if profile is None:
            return np.zeros(len(self.movie_ids))
        return cosine_similarity(profile, self.item_vectors)[0]

    def predict(self, user_id, movie_id):
        if movie_id not in self.m_index:
            return self.global_mean
        scores = self._score_all(user_id)
        sim = scores[self.m_index[movie_id]]
        return float(np.clip(self.global_mean + sim * 2, 1.0, 5.0))

    def recommend(self, user_id, k, exclude):
        scores = self._score_all(user_id)
        order = np.argsort(-scores)
        out = []
        for idx in order:
            m = self.movie_ids[idx]
            if m not in exclude:
                out.append(m)
                if len(out) == k:
                    break
        return out
