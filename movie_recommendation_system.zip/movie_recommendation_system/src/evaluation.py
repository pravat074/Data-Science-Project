"""
evaluation.py
-------------
Standard recommender-systems evaluation: rating-prediction accuracy
(RMSE, MAE) and ranking quality (Precision@K, Recall@K, Hit Rate, catalog
Coverage). A model can be strong on one axis and weak on the other -
predicting ratings accurately is a different skill from ranking the right
handful of movies at the very top of a list - so both are reported.
"""

import numpy as np
import pandas as pd


def train_test_split_ratings(ratings: pd.DataFrame, test_frac: float = 0.2, seed: int = 0,
                              min_train_per_user: int = 2):
    """
    Per-user random split so every user has at least `min_train_per_user`
    ratings in the training set (a pure random global split can otherwise
    leave some users with zero training history, which breaks every
    personalized model through no fault of its own).
    """
    rng = np.random.default_rng(seed)
    train_idx, test_idx = [], []
    for uid, grp in ratings.groupby("user_id"):
        idx = grp.index.values.copy()
        rng.shuffle(idx)
        n_test = int(len(idx) * test_frac)
        n_test = min(n_test, max(0, len(idx) - min_train_per_user))
        test_idx.extend(idx[:n_test])
        train_idx.extend(idx[n_test:])
    return ratings.loc[train_idx].reset_index(drop=True), ratings.loc[test_idx].reset_index(drop=True)


def rmse(y_true, y_pred) -> float:
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def mae(y_true, y_pred) -> float:
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    return float(np.mean(np.abs(y_true - y_pred)))


def rating_accuracy(model, test: pd.DataFrame) -> dict:
    preds = [model.predict(r.user_id, r.movie_id) for r in test.itertuples()]
    return {"rmse": rmse(test["rating"], preds), "mae": mae(test["rating"], preds)}


def precision_recall_at_k(model, train: pd.DataFrame, test: pd.DataFrame, k: int = 10,
                           relevance_threshold: float = 4.0, n_catalog: int = None):
    """
    For each user with at least one "relevant" item in the test set
    (rating >= relevance_threshold), ask the model for its top-K
    recommendations (excluding everything the user already rated in
    training) and check how many of the relevant test items were
    recovered. Also tracks catalog Coverage@K: the fraction of the whole
    catalog that shows up in *any* user's top-K list, a measure of
    whether a model just recommends the same handful of movies to everyone.
    """
    seen_by_user = train.groupby("user_id")["movie_id"].apply(set).to_dict()
    relevant_by_user = (
        test[test["rating"] >= relevance_threshold].groupby("user_id")["movie_id"].apply(set).to_dict()
    )

    precisions, recalls, hits = [], [], []
    recommended_union = set()
    eval_users = list(relevant_by_user.keys())

    for uid in eval_users:
        relevant = relevant_by_user[uid]
        exclude = seen_by_user.get(uid, set())
        recs = model.recommend(uid, k, exclude)
        recommended_union.update(recs)
        n_hit = len(set(recs) & relevant)
        precisions.append(n_hit / k)
        recalls.append(n_hit / len(relevant))
        hits.append(1 if n_hit > 0 else 0)

    coverage = len(recommended_union) / n_catalog if n_catalog else np.nan
    return {
        "precision_at_k": float(np.mean(precisions)) if precisions else np.nan,
        "recall_at_k": float(np.mean(recalls)) if recalls else np.nan,
        "hit_rate": float(np.mean(hits)) if hits else np.nan,
        "coverage": coverage,
        "n_eval_users": len(eval_users),
    }


def evaluate_all(models: dict, train: pd.DataFrame, test: pd.DataFrame, n_catalog: int,
                  k: int = 10, relevance_threshold: float = 4.0) -> pd.DataFrame:
    """Run rating-accuracy + ranking metrics for every {name: fitted model} and
    return one tidy summary row per model."""
    rows = []
    for name, model in models.items():
        acc = rating_accuracy(model, test)
        rank = precision_recall_at_k(model, train, test, k=k,
                                      relevance_threshold=relevance_threshold, n_catalog=n_catalog)
        rows.append({"model": name, **acc, **rank})
    return pd.DataFrame(rows)
