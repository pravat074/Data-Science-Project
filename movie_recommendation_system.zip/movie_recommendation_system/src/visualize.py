"""
visualize.py
------------
Matplotlib plotting helpers: dataset diagnostics plus model-comparison
charts. Kept dependency-light (matplotlib + sklearn's PCA only).
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def plot_rating_distribution(ratings_df, out_path):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    axes[0].hist(ratings_df["rating"], bins=np.arange(0.75, 5.5, 0.5), color="#1C7293", edgecolor="white")
    axes[0].set_title("Rating distribution")
    axes[0].set_xlabel("Rating")
    axes[0].set_ylabel("Count")

    counts = ratings_df.groupby("movie_id").size().sort_values(ascending=False).values
    axes[1].plot(np.arange(1, len(counts) + 1), counts, color="#E8A33D")
    axes[1].set_title("Ratings per movie (sorted)\n— the long tail")
    axes[1].set_xlabel("Movie rank (most → least rated)")
    axes[1].set_ylabel("Number of ratings")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def plot_genre_popularity(movies_df, ratings_df, out_path):
    merged = ratings_df.merge(movies_df[["movie_id", "genres"]], on="movie_id")
    exploded = merged.assign(genre=merged["genres"].str.split("|")).explode("genre")
    stats = exploded.groupby("genre")["rating"].agg(["mean", "count"]).sort_values("count", ascending=False)

    fig, ax1 = plt.subplots(figsize=(9, 4.5))
    ax1.bar(stats.index, stats["count"], color="#0D2B45")
    ax1.set_ylabel("Number of ratings", color="#0D2B45")
    ax1.tick_params(axis="x", rotation=35)
    ax2 = ax1.twinx()
    ax2.plot(stats.index, stats["mean"], color="#E8A33D", marker="o", linewidth=2)
    ax2.set_ylabel("Average rating", color="#E8A33D")
    ax1.set_title("Ratings volume and average score by genre")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def plot_model_comparison(summary_df, out_path):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.3))
    plots = [
        (["rmse", "mae"], "Rating-prediction error (lower is better)", axes[0]),
        (["precision_at_k", "recall_at_k"], "Top-K ranking quality (higher is better)", axes[1]),
        (["coverage"], "Catalog coverage @K (higher = less repetitive)", axes[2]),
    ]
    colors = ["#1C7293", "#E8A33D"]
    for cols, title, ax in plots:
        x = np.arange(len(summary_df))
        width = 0.8 / len(cols)
        for j, col in enumerate(cols):
            ax.bar(x + j * width, summary_df[col], width=width, label=col, color=colors[j % 2])
        ax.set_xticks(x + width * (len(cols) - 1) / 2)
        ax.set_xticklabels(summary_df["model"], rotation=30, ha="right", fontsize=8)
        ax.set_title(title, fontsize=10)
        if len(cols) > 1:
            ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def plot_latent_space(mf_model, movies_df, out_path):
    """PCA-project the learned item latent vectors to 2D, colored by each
    movie's primary genre - if matrix factorization is working, movies of
    the same genre should visibly cluster even though genre was never
    given to the model directly."""
    from sklearn.decomposition import PCA

    Q = mf_model.Q
    coords = PCA(n_components=2, random_state=0).fit_transform(Q)
    primary_genre = movies_df.set_index("movie_id").loc[mf_model.movie_ids, "genres"].str.split("|").str[0]

    fig, ax = plt.subplots(figsize=(7.5, 6))
    genres = sorted(primary_genre.unique())
    cmap = plt.get_cmap("tab10")
    for i, g in enumerate(genres):
        mask = (primary_genre == g).values
        ax.scatter(coords[mask, 0], coords[mask, 1], s=22, alpha=0.75, color=cmap(i % 10), label=g)
    ax.set_title("Learned movie latent space (PCA), colored by genre\n— genre was never given to the model")
    ax.set_xlabel("PC 1")
    ax.set_ylabel("PC 2")
    ax.legend(fontsize=7, ncol=2, loc="best")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def plot_mf_training_curve(mf_model, out_path):
    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.plot(range(1, len(mf_model.train_rmse_history) + 1), mf_model.train_rmse_history, color="#0D2B45")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Training RMSE")
    ax.set_title("Matrix factorization — SGD training curve")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
