"""
synthetic_data.py
------------------
Generates a realistic synthetic movie catalog and user-rating matrix when
no live catalog/ratings API (TMDB, MovieLens, a production ratings DB) is
connected. See README.md for how to swap this for a real dataset.

The generator is designed to reproduce the key stylised facts of real
recommender-system data, not to look like any specific real catalog:

  1. Latent taste structure: every user and every movie has a latent
     preference vector; a user's rating is driven mainly by the dot
     product of their vector with the movie's vector, plus user/movie
     bias terms (some users rate everything higher, some movies are
     just better) and noise.
  2. Popularity skew: a small number of movies attract most of the
     ratings (the long tail seen in every real catalog), and users vary
     widely in how many movies they rate.
  3. Missing-not-at-random sparsity: users are far more likely to have
     rated a popular movie than an obscure one, exactly the selection
     bias that makes real recommender evaluation hard.

Movie titles are procedurally generated from word banks - they are not
drawn from, and do not correspond to, any real film.
"""

import numpy as np
import pandas as pd

GENRES = [
    "Action", "Comedy", "Drama", "Sci-Fi", "Romance",
    "Thriller", "Horror", "Animation", "Documentary", "Fantasy",
]

# each genre is anchored to a point in a K-dimensional taste space so that
# movies of the same genre cluster together (and users can have a genre
# "type"), while still leaving room for individual variation.
LATENT_DIM = 12

_ADJ = [
    "Silent", "Broken", "Last", "Hidden", "Crimson", "Distant", "Endless",
    "Forgotten", "Golden", "Iron", "Lonely", "Midnight", "Northern", "Quiet",
    "Rogue", "Scarlet", "Shattered", "Twilight", "Velvet", "Wild",
]
_NOUN = [
    "Horizon", "Protocol", "Garden", "Machine", "River", "Kingdom", "Signal",
    "Harbor", "Echo", "Empire", "Labyrinth", "Orchard", "Voyage", "Verdict",
    "Storm", "Legacy", "Mirage", "Anthem", "Descent", "Covenant",
]
_TEMPLATES = [
    "{adj} {noun}",
    "The {adj} {noun}",
    "{noun} of {adj2}",
    "{adj} and {adj2}",
]


def _make_title(rng, used):
    while True:
        t = rng.choice(_TEMPLATES)
        title = t.format(
            adj=rng.choice(_ADJ), adj2=rng.choice(_ADJ), noun=rng.choice(_NOUN)
        )
        if title not in used:
            used.add(title)
            return title


def generate_movies(n_movies: int = 200, seed: int = 7) -> tuple[pd.DataFrame, np.ndarray]:
    """
    Returns (movies_df, movie_vectors) where movies_df has columns
    movie_id, title, genres (comma-separated), year, n_genre_tags, quality_bias,
    and movie_vectors is an (n_movies, LATENT_DIM) array used internally by
    the rating model (and re-used directly by the matrix-factorization
    ground truth check / content-based cold-start demo).
    """
    rng = np.random.default_rng(seed)
    genre_anchor = rng.normal(0, 0.45, size=(len(GENRES), LATENT_DIM))

    used_titles = set()
    rows = []
    vectors = np.zeros((n_movies, LATENT_DIM))
    # popularity follows a power law - a few blockbusters, a long tail
    popularity_rank = rng.permutation(n_movies)
    for i in range(n_movies):
        n_tags = 1 if rng.random() < 0.55 else 2
        tags = rng.choice(len(GENRES), size=n_tags, replace=False)
        vec = genre_anchor[tags].mean(axis=0) + rng.normal(0, 0.15, size=LATENT_DIM)
        vectors[i] = vec
        quality_bias = rng.normal(0, 0.4)
        pop_rank = popularity_rank[i]
        rows.append({
            "movie_id": i,
            "title": _make_title(rng, used_titles),
            "genres": "|".join(GENRES[t] for t in tags),
            "year": int(rng.integers(1980, 2025)),
            "quality_bias": quality_bias,
            "popularity_rank": int(pop_rank),  # 0 = most popular
        })
    movies_df = pd.DataFrame(rows)
    return movies_df, vectors


def generate_users(n_users: int = 500, seed: int = 11) -> tuple[pd.DataFrame, np.ndarray]:
    """Returns (users_df, user_vectors); users_df has user_id, bias, activity_level."""
    rng = np.random.default_rng(seed)
    vectors = rng.normal(0, 0.45, size=(n_users, LATENT_DIM))
    bias = rng.normal(0, 0.35, size=n_users)
    # activity level (lognormal) drives how many movies each user rates
    activity = rng.lognormal(mean=3.0, sigma=0.8, size=n_users)
    users_df = pd.DataFrame({
        "user_id": np.arange(n_users),
        "bias": bias,
        "activity_level": activity,
    })
    return users_df, vectors


def generate_ratings(
    movies_df: pd.DataFrame,
    movie_vectors: np.ndarray,
    users_df: pd.DataFrame,
    user_vectors: np.ndarray,
    global_mean: float = 3.5,
    noise_sd: float = 0.4,
    seed: int = 23,
) -> pd.DataFrame:
    """
    Simulate which (user, movie) pairs are observed, and what rating each
    produces. Popularity strongly drives observation probability (a
    blockbuster is far more likely to have been watched-and-rated than an
    obscure title); the rating itself follows the latent-factor model.
    """
    rng = np.random.default_rng(seed)
    n_users, n_movies = len(users_df), len(movies_df)

    # observation probability per movie: popular movies (low popularity_rank)
    # are watched far more often - roughly a Zipf-like decay.
    rank = movies_df["popularity_rank"].values.astype(float)
    movie_weight = 1.0 / (rank + 10) ** 0.85
    movie_weight = movie_weight / movie_weight.sum()

    records = []
    for u in range(n_users):
        n_rate = int(np.clip(users_df.loc[u, "activity_level"], 3, n_movies * 0.6))
        chosen = rng.choice(n_movies, size=n_rate, replace=False, p=movie_weight)
        dot = movie_vectors[chosen] @ user_vectors[u]
        bias_u = users_df.loc[u, "bias"]
        bias_i = movies_df.loc[chosen, "quality_bias"].values
        raw = global_mean + bias_u + bias_i + dot + rng.normal(0, noise_sd, size=n_rate)
        rating = np.clip(np.round(raw * 2) / 2, 1.0, 5.0)  # round to nearest 0.5, clip 1-5
        ts_base = 1_700_000_000
        timestamps = ts_base + rng.integers(0, 60_000_000, size=n_rate)
        for m, r, t in zip(chosen, rating, timestamps):
            records.append((u, int(m), float(r), int(t)))

    ratings_df = pd.DataFrame(records, columns=["user_id", "movie_id", "rating", "timestamp"])
    ratings_df = ratings_df.drop_duplicates(subset=["user_id", "movie_id"]).reset_index(drop=True)
    return ratings_df


def generate_dataset(n_users=500, n_movies=200, seed=42):
    """Convenience wrapper: build movies, users and ratings in one call."""
    movies_df, movie_vecs = generate_movies(n_movies, seed=seed)
    users_df, user_vecs = generate_users(n_users, seed=seed + 1)
    ratings_df = generate_ratings(movies_df, movie_vecs, users_df, user_vecs, seed=seed + 2)
    return movies_df, movie_vecs, users_df, user_vecs, ratings_df


if __name__ == "__main__":
    movies, mvecs, users, uvecs, ratings = generate_dataset()
    print(movies.head())
    print(f"\n{len(ratings)} ratings across {users.shape[0]} users and {movies.shape[0]} movies")
    print(f"Density: {len(ratings) / (users.shape[0] * movies.shape[0]):.2%}")
