"""
main.py
-------
End-to-end run: generate a synthetic movie catalog + rating history, split
into train/test, fit five recommendation algorithms, evaluate them all on
the same metrics, save results, and print sample recommendations for a
demo user.

Usage:
    python main.py
"""

import os
import pandas as pd

from src.synthetic_data import generate_dataset
from src.recommenders import (
    PopularityRecommender, NeighborhoodCF, MatrixFactorizationRecommender, ContentBasedRecommender,
)
from src.evaluation import train_test_split_ratings, evaluate_all
from src import visualize

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")
N_USERS, N_MOVIES = 500, 200
TOP_K = 10
DEMO_USER = 0


def run():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("Generating synthetic catalog and rating history...")
    movies, movie_vecs, users, user_vecs, ratings = generate_dataset(N_USERS, N_MOVIES, seed=42)
    movies.to_csv(f"{OUTPUT_DIR}/movies.csv", index=False)
    ratings.to_csv(f"{OUTPUT_DIR}/ratings.csv", index=False)
    print(f"  {len(ratings)} ratings, {N_USERS} users, {N_MOVIES} movies "
          f"(density {len(ratings) / (N_USERS * N_MOVIES):.2%})")

    train, test = train_test_split_ratings(ratings, test_frac=0.2, seed=0)
    print(f"  train={len(train)}  test={len(test)}")

    print("Fitting models...")
    models = {
        "Popularity": PopularityRecommender().fit(train),
        "User-Based CF": NeighborhoodCF(mode="user").fit(train),
        "Item-Based CF": NeighborhoodCF(mode="item").fit(train),
        "Matrix Factorization": MatrixFactorizationRecommender(n_factors=20, n_epochs=30).fit(train),
        "Content-Based": ContentBasedRecommender().fit(train, movies_df=movies),
    }

    print("Evaluating (RMSE / MAE / Precision@K / Recall@K / Coverage@K)...")
    summary = evaluate_all(models, train, test, n_catalog=N_MOVIES, k=TOP_K, relevance_threshold=4.0)
    summary.to_csv(f"{OUTPUT_DIR}/model_comparison.csv", index=False)

    print("\n=== Model comparison ===")
    pd.set_option("display.float_format", lambda x: f"{x:,.4f}")
    print(summary.to_string(index=False))

    print("\nRendering plots...")
    visualize.plot_rating_distribution(ratings, f"{OUTPUT_DIR}/rating_distribution.png")
    visualize.plot_genre_popularity(movies, ratings, f"{OUTPUT_DIR}/genre_popularity.png")
    visualize.plot_model_comparison(summary, f"{OUTPUT_DIR}/model_comparison.png")
    visualize.plot_mf_training_curve(models["Matrix Factorization"], f"{OUTPUT_DIR}/mf_training_curve.png")
    visualize.plot_latent_space(models["Matrix Factorization"], movies, f"{OUTPUT_DIR}/latent_space.png")

    print(f"\n=== Top {TOP_K} recommendations for user {DEMO_USER} ===")
    seen = set(train.loc[train["user_id"] == DEMO_USER, "movie_id"])
    movies_idx = movies.set_index("movie_id")
    for name, model in models.items():
        recs = model.recommend(DEMO_USER, TOP_K, exclude=seen)
        titles = [movies_idx.loc[m, "title"] for m in recs[:5]]
        print(f"  {name:22s}: " + " | ".join(titles))

    print(f"\nAll CSVs and plots written to: {OUTPUT_DIR}")


if __name__ == "__main__":
    run()
